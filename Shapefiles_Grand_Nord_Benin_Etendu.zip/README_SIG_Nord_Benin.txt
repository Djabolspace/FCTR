=== SYSTEME D'INFORMATION GEOGRAPHIQUE (SIG) - BENIN SEPTENTRIONAL ===
Projet : Extension de la Base de Données Cartographique de la Forêt Classée des Trois Rivières (FCTR)

Ce dossier compressé contient les couches géospatiales (Shapefiles) élargies à l'ensemble du complexe territorial, administratif et environnemental du Nord-Bénin.

Projection de Référence :
- Système Géodésique Mondial : WGS 84 (EPSG:4326)
- Pour les calculs de superficie précis, projeter en : WGS 84 / UTM Zone 31N (EPSG:32631)

CONTENU DU ZIP :
1. Departements_Grand_Nord (Borgou, Alibori, Atacora, Donga) :
   Limites polygonales des 4 grands départements du Nord-Bénin pour les analyses macro-régionales.
2. Communes_Riveraines_Et_Frontalieres_Elargies :
   Toutes les communes périphériques et adjacentes impliquées directement ou indirectement (Transhumance, bassins versants).
3. Reseau_Hydrographique_Bassin_Niger_Sota :
   Tracé complet des cours d'eau majeurs du nord (Sota, Alibori, Niger, Pendjari, Mekrou) pour l'analyse d'impact climatique.
4. Aires_Protegees_Complexe_Nord (FCTR, Parc W, Parc Pendjari) :
   Ensemble des forêts classées et parcs nationaux connectés écologiquement à la FCTR.
