========================================================================
PACK SIG : FORÊT CLASSÉE DES TROIS RIVIÈRES (FCTR) - BÉNIN
========================================================================
Ce fichier compressé contient les couches vectorielles de référence (Shapefiles)
permettant d'étudier la Forêt Classée des Trois Rivières et sa périphérie agropastorale.

PROJECTION DE RÉFÉRENCE :
- Système de coordonnées : GCS_WGS_1984 (EPSG: 4326)
- Unités : Degrés décimaux
- Zone : Nord-Est du Bénin (Départements du Borgou et de l'Alibori)

LISTE DES COUCHES VECTORIELLES INCLUSES :
1. FCTR_Limite_Officielle.*
   - Type : Polygone
   - Description : Périmètre officiel de classement de la réserve (approx. 268 530 ha) basé sur le décret initial et révisé.
   
2. FCTR_Communes_Riveraines_Borgou_Alibori.*
   - Type : Polygone
   - Description : Limites administratives des 7 communes périphériques et riveraines (Kalalé, Bembèrèkè, Nikki, Gogounou, Ségbana, Kandi, Banikoara).
   
3. FCTR_Reseau_Hydrographique_Superieur.*
   - Type : Polyligne / Ligne
   - Description : Tracé des rivières éponymes majeures : la Sota, la Tassiné, et la Bouli.

4. FCTR_Zonage_PAP_2024.*
   - Type : Polygone
   - Description : Délimitation des Unités d'Aménagement Forestier (UAF) et zones de conservation stricte (Décret N° 2024-902).

INSTRUCTIONS D'UTILISATION :
- Pour charger correctement ces données sous QGIS ou ArcGIS, veillez à importer simultanément les extensions associées (.shp, .shx, .dbf, .prj) pour chaque couche.
- Les données OpenStreetMap et les couches hydrographiques complètes du Bénin peuvent également être enrichies via le portail HDX (Humanitarian Data Exchange).
